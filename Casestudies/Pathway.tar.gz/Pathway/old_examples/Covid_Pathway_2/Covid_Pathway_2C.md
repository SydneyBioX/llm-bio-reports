    suppressMessages({
      library(SingleCellExperiment)
      library(clusterProfiler)
      library(limma)
    })

# LLM Task

This is a Gene Set Enrichment Analysis (GSEA) of COVID patients. The two
groups of interest are: healthy and SARS-CoV-2. We pass in the negative
log p-values from a DE analysis as the order ranked gene list. Please
look at the plot.png file and summarize what you see.

    sce <- readRDS('/Users/mayashen/Desktop/bioinfo-llm/data/covid/sce_chua_20200721.rds')
    sce$infection <- factor(sce$infection, levels=c("healthy", "SARS-CoV-2"))
    sce <- sce[!(rowSums(logcounts(sce))==0),]

    set.seed(42)
    subsmp_case_cells <- sample(colnames(sce[, sce$infection == "SARS-CoV-2"]), 10000)
    sce_subsmp <- sce[, c(colnames(sce[, sce$infection == "healthy"]), subsmp_case_cells)]

## DE genes

    design_matrix <- model.matrix(~sce_subsmp$infection)
    colnames(design_matrix) <- c("intercept", "SARS-CoV-2")

    fit <- lmFit(logcounts(sce_subsmp), design_matrix)
    fit <- eBayes(fit)
    tt <- topTable(fit, number=Inf, coef=2, adjust.method="bonferroni")
    tt$neg_log10pvalue <- -log10(tt$adj.P.Val+.Machine$double.xmin)
    tt <- tt[order(tt$neg_log10pvalue, decreasing=TRUE),]

## GSEA

    organism <- "org.Hs.eg.db"

    top_df <- tt[tt$adj.P.Val < 0.1, ]
    gene_list <- top_df$neg_log10pvalue
    names(gene_list) <- rownames(top_df)
    gse <- gseGO(geneList=gene_list, 
                 ont ="BP", 
                 keyType = "SYMBOL", 
                 nPerm = 10000, 
                 minGSSize = 10, 
                 maxGSSize = 500, 
                 pvalueCutoff = 0.5, 
                 verbose = FALSE, 
                 OrgDb = organism, 
                 pAdjustMethod = "BH")

    df <- data.frame(gse@result[,c(1,2,7)])
    df[,3] <- signif(df[,3], digits=3)
    head(df, 5)

    ##                    ID                                     Description p.adjust
    ## GO:0046596 GO:0046596        regulation of viral entry into host cell  0.00454
    ## GO:0045104 GO:0045104 intermediate filament cytoskeleton organization  0.00454
    ## GO:0045103 GO:0045103             intermediate filament-based process  0.00454
    ## GO:0034109 GO:0034109                    homotypic cell-cell adhesion  0.00454
    ## GO:0031638 GO:0031638                              zymogen activation  0.00454
