``` r
library(dplyr)
library(magrittr)
library(janitor)
library(tidyr)
library(stringr)
library(funkyheatmap)
library(ggthemr)
library(readr)
```

# load data

``` r
column_info_detailed1 <- read.csv("/Users/cabiria/Downloads/column_info_detailed1.csv")
funkeyheatmap_result <- read.csv("/Users/cabiria/Downloads/funkeyheatmap_result.csv")
column_groups <- read.csv("/Users/cabiria/Downloads/column_groups.csv")
```

# Draw funkyheatmap

``` r
g <- funky_heatmap(
  data = funkeyheatmap_result,
  column_info = column_info_detailed1,
  column_groups = column_groups
)


# "Greys", "Blues", "Reds", "YlOrBr", "Greens"

g
```

![](funkyheatmap_files/figure-markdown_github/unnamed-chunk-3-1.png)

``` r
# ggplot2::ggsave("funkyheatmap1.pdf", g, width = 20, height = 15, dpi=300)
```

# Output the data point as direct input for LLM

``` r
# write.csv(funkeyheatmap_result, "/Users/cabiria/Downloads/funkeyheatmap_result.csv")
# write.csv(column_info_detailed1, "/Users/cabiria/Downloads/column_info_detailed1.csv")
# write.csv(column_groups, "/Users/cabiria/Downloads/column_groups.csv")
```

# Question for LLM

Question: Which simulator is the beset in overall score?  
A: SRTsim.  
B: SPARsim.  
C: symsim.  
D: scDesign3.

Question: Any relationship between different metrics in same spatial
task?  
A: Yes  
B: No. 
