Task: This is a spatial analysis of a spatial experiment object of lung
cancer data set (assigned as spe) loaded into the environment. You will
either have information of the UMAP coordinates or the UMAP plot with
the different cell types highlighted or the actual graphics. From this
information, please provide a description of the data, such as the
neighboring cell types and number of cell types and how they compare to
each other spatially.

    suppressPackageStartupMessages({
      library(SpatialExperiment)
      library(scater)
      library(scuttle)
      library(ggplot2)
      library(patchwork)
      library(SpaNorm)
      library(data.table)
      library(standR)
      library(bluster)
    })

This analysis applies UMAP for dimensional reduction and uses
graph-based clustering to explore the clustering patterns of cell types
in spatial transcriptiomic data. Finally, a visualization is generated,
plotting cell types based on UMAP coordinates and annotating them by
region for interpretation.

    spe <- readRDS("../spe.rds")

    clustering <- clusterRows(reducedDim(spe, "UMAP"), BLUSPARAM = KNNGraphParam(k =100))
    colData(spe)$cluster <- as.factor(clustering)
    umap_coords = merge(reducedDim(spe, type = 'UMAP'), spe@colData[,c("cell_type", "cluster")], by = 'row.names')[,2:5]
    write.csv(umap_coords, "umap.csv", row.names = F)


    p1 = plotDR(spe, dimred = "UMAP", colour = cell_type, alpha = 0.75, size = 1) +
      scale_colour_brewer(palette = "Paired") +
      labs(x = "UMAP1", y = "UMAP2") +
      theme(legend.position = "right") + ggtitle("UMAP - clusters")

    p2 = plotDR(spe, dimred = "UMAP", colour = cluster, alpha = 0.75, size = 1) +
      scale_colour_brewer(palette = "Paired") +
      labs(x = "UMAP1", y = "UMAP2") +
      theme(legend.position = "right") + ggtitle("UMAP - clusters")

    p1 + p2

![](umap_files/figure-markdown_strict/unnamed-chunk-2-1.png)
